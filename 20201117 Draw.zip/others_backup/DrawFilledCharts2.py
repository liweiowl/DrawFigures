import numpy as np
import matplotlib.pyplot as plt

N = 7
menMeans = (59, 63, 53, 65, 61, 52, 69)
menStd = (14, 25, 4, 15, 5, 10, 30)
ind = np.arange(N)    # the x locations for the groups
width = 0.35       # the width of the bars: can also be len(x) sequence

p1 = plt.bar(ind, menMeans, width, yerr=menStd, ecolor='red')
#p2 = plt.bar(ind, womenMeans, width,
#             bottom=menMeans, yerr=womenStd)

plt.ylabel('Score', fontname="Arial", fontsize=18)
plt.title('The score distribution of different features',  fontsize=18, fontname='Comic Sans MS')
plt.xticks(ind, ('T', 'I', 'W', 'E', 'S', 'Ep', 'Em'),  fontsize=18, fontname="Arial")
plt.yticks(np.arange(0, 110, 10))
#plt.legend((p1[0], p2[0]), ('Men', 'Women'))

plt.show()