import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import seaborn as sns
import os
import re

sns.set_style('whitegrid')

returnavg = (59, 63, 53, 65, 61, 52, 69)
returnstd = (1, 2, 4, 5, 5, 2, 3)

color = cm.viridis(0.7)
f, ax = plt.subplots(1, 1)
ax.plot([i for i in range(1, 8)], returnavg, color=color)
r1 = list(map(lambda x: x[0]-x[1], zip(returnavg, returnstd)))
r2 = list(map(lambda x: x[0]+x[1], zip(returnavg, returnstd)))
ax.fill_between([i for i in range(1, 8)], r1, r2, color=color, alpha=0.2)
ax.legend()
ax.set_xlabel('epoch')
ax.set_ylabel('value')
exp_dir = 'Plot/'
if not os.path.exists(exp_dir):
    os.makedirs(exp_dir, exist_ok=True)
f.savefig(os.path.join('Plot', 'avgvalue' + '.png'), dpi=300)

print('hello world')